-- =====================================================
-- 1. DATABASE & SCHEMA
-- =====================================================
USE DATABASE FOOD_DELIVERY_DB;
USE SCHEMA RAW;

-- =====================================================
-- 2. LOAD DATA (RAW LAYER)
-- =====================================================
COPY INTO customers_raw 
FROM @food_stage/customers_merged.csv;

COPY INTO restaurants_raw
FROM @food_stage/restaurants_merged.csv;

COPY INTO couriers_raw 
FROM @food_stage/couriers_merged.csv;

COPY INTO orders_raw 
FROM @food_stage/orders_merged.csv;

COPY INTO order_items_raw 
FROM @food_stage/order_items_merged.csv;

COPY INTO deliveries_raw 
FROM @food_stage/deliveries_merged.csv;


SELECT COUNT(*) FROM customers_raw;
SELECT COUNT(*) FROM orders_raw;
 

-- validation check--
SELECT COUNT(*) AS raw_order_items
FROM FOOD_DELIVERY_DB.RAW.order_items_raw;

USE DATABASE FOOD_DELIVERY_DB;
USE SCHEMA RAW;

-- PROFILE CUSTOMER DATA
-- Row count
SELECT COUNT(*) AS total_customers
FROM customers_raw;
--NULL CHECK
SELECT
    COUNT(*) AS total_rows,
    COUNT_IF(customer_id IS NULL) AS null_customer_id,
    COUNT_IF(first_name IS NULL) AS null_first_name,
    COUNT_IF(email IS NULL) AS null_email,
    COUNT_IF(city IS NULL) AS null_city,
    COUNT_IF(created_at IS NULL) AS null_created_at
FROM customers_raw;

-- DUPLICATE CHECK
SELECT customer_id, COUNT(*)
FROM customers_raw
GROUP BY customer_id
HAVING COUNT(*) > 1;

-- PROFILE RESTAURANTS DATA
-- Row Count
SELECT COUNT(*) AS total_restaurants
FROM restaurants_raw;
-- NULL CHECK
SELECT
    COUNT_IF(restaurant_id IS NULL) AS null_restaurant_id,
    COUNT_IF(restaurant_name IS NULL) AS null_name,
    COUNT_IF(city IS NULL) AS null_city,
    COUNT_IF(rating IS NULL) AS null_rating
FROM restaurants_raw;
-- DUPLICATE CHECK
SELECT restaurant_id, COUNT(*)
FROM restaurants_raw
GROUP BY restaurant_id
HAVING COUNT(*) > 1;

-- PROFILE COURIERS DATA
-- Row Count
SELECT COUNT(*) AS total_couriers
FROM couriers_raw;
-- NULL CHECK
SELECT
    COUNT_IF(courier_id IS NULL) AS null_courier_id,
    COUNT_IF(courier_name IS NULL) AS null_name,
    COUNT_IF(city IS NULL) AS null_city
FROM couriers_raw;
-- DUPLICATE CHECK
SELECT courier_id, COUNT(*)
FROM couriers_raw
GROUP BY courier_id
HAVING COUNT(*) > 1;

-- PROFILE ORDERS DATA
-- Row Count
SELECT COUNT(*) AS total_orders
FROM orders_raw;
-- NULL CHECK
SELECT
    COUNT_IF(order_id IS NULL) AS null_order_id,
    COUNT_IF(customer_id IS NULL) AS null_customer_id,
    COUNT_IF(restaurant_id IS NULL) AS null_restaurant_id,
    COUNT_IF(order_datetime IS NULL) AS null_datetime
FROM orders_raw;
-- DUPLICATE CHECK
SELECT order_id, COUNT(*)
FROM orders_raw
GROUP BY order_id
HAVING COUNT(*) > 1;

-- PROFILE ORDER ITEMS DATA
-- Row Count
SELECT COUNT(*) AS total_order_items
FROM order_items_raw;
-- NULL CHECK
SELECT
    COUNT_IF(order_item_id IS NULL) AS null_item_id,
    COUNT_IF(order_id IS NULL) AS null_order_id,
    COUNT_IF(quantity IS NULL) AS null_quantity,
    COUNT_IF(unit_price IS NULL) AS null_unit_price
FROM order_items_raw;
-- DUPLICATE CHECK
SELECT order_item_id, COUNT(*)
FROM order_items_raw
GROUP BY order_item_id
HAVING COUNT(*) > 1;

-- PROFILE DELIVERIES DATA
-- Row Count
SELECT COUNT(*) AS total_deliveries
FROM deliveries_raw;
-- NULL CHECK
SELECT
    COUNT_IF(delivery_id IS NULL) AS null_delivery_id,
    COUNT_IF(order_id IS NULL) AS null_order_id,
    COUNT_IF(courier_id IS NULL) AS null_courier_id,
    COUNT_IF(assign_time IS NULL) AS null_assign_time,
    COUNT_IF(drop_time IS NULL) AS null_drop_time
FROM deliveries_raw;
-- DUPLICATE CHECK
SELECT delivery_id, COUNT(*)
FROM deliveries_raw
GROUP BY delivery_id
HAVING COUNT(*) > 1;

-- DATA DISTRIBUTION CHECKS
-- Distinct Quantity & Revenue
SELECT 
    COUNT(DISTINCT quantity) AS distinct_quantity,
    COUNT(DISTINCT line_amount) AS distinct_line_amount
FROM order_items_raw;
-- High Value Orders
SELECT *
FROM order_items_raw
WHERE TRY_TO_NUMBER(line_amount) > 10000;
-- Orders Per City
SELECT city, COUNT(*) AS total_orders
FROM orders_raw
GROUP BY city
ORDER BY total_orders DESC;

-- BUSINESS RULE CHECKS
-- Negative Quantity
SELECT *
FROM order_items_raw
WHERE TRY_TO_NUMBER(quantity) < 0;
-- Future Orders
SELECT *
FROM orders_raw
WHERE order_datetime > CURRENT_TIMESTAMP();

-- Delivery Drop Before Assign
SELECT *
FROM deliveries_raw
WHERE drop_time < assign_time;

-- DATA PROFILING COMPLETE
-- =====================================================
-- What We Just Did

-- You validated:
-- Row counts
-- Null values
-- Duplicate records
-- Negative numbers
-- Future dates
-- Logical time issues
-- Data distribution
