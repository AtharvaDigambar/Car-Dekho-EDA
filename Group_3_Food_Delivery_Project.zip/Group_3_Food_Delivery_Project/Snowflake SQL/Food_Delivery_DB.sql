CREATE DATABASE FOOD_DELIVERY_DB;
USE DATABASE FOOD_DELIVERY_DB;

CREATE SCHEMA RAW;
USE SCHEMA RAW;

CREATE FILE FORMAT csv_format
TYPE = CSV
FIELD_OPTIONALLY_ENCLOSED_BY = '"'
SKIP_HEADER = 1;

CREATE STAGE food_stage
FILE_FORMAT = csv_format;

-- now we are going to create oltp raw table 
CREATE TABLE customers_raw (
customer_id STRING,
first_name STRING,
last_name STRING,
gender STRING,
email STRING,
city STRING,
state STRING,
created_at TIMESTAMP
);

CREATE TABLE restaurants_raw (
restaurant_id STRING,
restaurant_name STRING,
cuisine STRING,
city STRING,
state STRING,
rating STRING,
is_active STRING
);

CREATE TABLE couriers_raw (
courier_id STRING,
courier_name STRING,
vehicle_type STRING,
phone STRING,
city STRING,
state STRING,
is_active STRING
);

CREATE TABLE orders_raw (
order_id STRING,
customer_id STRING,
restaurant_id STRING,
order_datetime TIMESTAMP,
status STRING,
city STRING,
state STRING
);

CREATE TABLE order_items_raw (
order_item_id STRING,
order_id STRING,
menu_code STRING,
quantity STRING,
unit_price STRING,
line_amount STRING
);

CREATE TABLE deliveries_raw (
delivery_id STRING,
order_id STRING,
courier_id STRING,
assign_time TIMESTAMP,
drop_time TIMESTAMP,
distance_km STRING
);

