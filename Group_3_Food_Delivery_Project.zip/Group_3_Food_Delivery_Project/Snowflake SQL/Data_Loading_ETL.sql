-- =====================================================
-- 1. DATABASE & SCHEMA
-- =====================================================
USE DATABASE FOOD_DELIVERY_DB;
USE SCHEMA RAW;


-- =====================================================
-- 3. CLEAN LAYER (REMOVE DUPLICATES + FIX DATA)
-- =====================================================

-- CUSTOMERS
CREATE OR REPLACE TABLE customers_clean AS
SELECT
    customer_id,
    TRIM(first_name) AS first_name,
    LOWER(email) AS email,
    INITCAP(city) AS city,
    created_at
FROM (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY created_at DESC) AS rn
    FROM customers_raw
    WHERE customer_id IS NOT NULL
)
WHERE rn = 1;

-- RESTAURANTS
CREATE OR REPLACE TABLE restaurants_clean AS
SELECT
    restaurant_id,
    TRIM(restaurant_name) AS restaurant_name,
    INITCAP(cuisine) AS cuisine,
    INITCAP(city) AS city,
    TRY_TO_NUMBER(rating) AS rating
FROM (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY restaurant_id ORDER BY rating DESC) AS rn
    FROM restaurants_raw
    WHERE restaurant_id IS NOT NULL
)
WHERE rn = 1;

-- COURIERS
CREATE OR REPLACE TABLE couriers_clean AS
SELECT
    courier_id,
    TRIM(courier_name) AS courier_name,
    INITCAP(city) AS city
FROM (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY courier_id ORDER BY courier_id) AS rn
    FROM couriers_raw
    WHERE courier_id IS NOT NULL
)
WHERE rn = 1;

-- ORDERS
CREATE OR REPLACE TABLE orders_clean AS
SELECT
    order_id,
    customer_id,
    restaurant_id,
    order_datetime,
    INITCAP(city) AS city
FROM (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY order_id ORDER BY order_datetime DESC) AS rn
    FROM orders_raw
    WHERE order_id IS NOT NULL
      AND order_datetime <= CURRENT_TIMESTAMP()
)
WHERE rn = 1;

-- ORDER ITEMS
CREATE OR REPLACE TABLE order_items_clean AS
SELECT
    order_item_id,
    order_id,
    TRY_TO_NUMBER(quantity) AS quantity,
    TRY_TO_NUMBER(unit_price) AS unit_price,
    TRY_TO_NUMBER(line_amount) AS line_amount
FROM (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY order_item_id ORDER BY order_item_id) AS rn
    FROM order_items_raw
    WHERE order_item_id IS NOT NULL
      AND TRY_TO_NUMBER(quantity) >= 0
      AND TRY_TO_NUMBER(line_amount) <= 10000
)
WHERE rn = 1;

-- DELIVERIES
CREATE OR REPLACE TABLE deliveries_clean AS
SELECT
    delivery_id,
    order_id,
    courier_id,
    assign_time,
    drop_time
FROM (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY delivery_id ORDER BY assign_time DESC) AS rn
    FROM deliveries_raw
    WHERE delivery_id IS NOT NULL
      AND drop_time >= assign_time
)
WHERE rn = 1;

-- =====================================================
-- 4. DIMENSION TABLES (GOLD LAYER)
-- =====================================================

-- CUSTOMERS (SCD TYPE 2)
CREATE OR REPLACE TABLE dim_customers (
    customer_key INT AUTOINCREMENT,
    customer_id VARCHAR,
    first_name VARCHAR,
    email VARCHAR,
    city VARCHAR,
    created_at TIMESTAMP,
    effective_start_date TIMESTAMP,
    effective_end_date TIMESTAMP,
    is_current BOOLEAN
);

-- INITIAL LOAD
INSERT INTO dim_customers (
    customer_id, first_name, email, city, created_at,
    effective_start_date, effective_end_date, is_current
)
SELECT
    customer_id, first_name, email, city, created_at,
    CURRENT_TIMESTAMP(), NULL, TRUE
FROM customers_clean;

-- SCD TYPE 2 UPDATE (FIXED)
-- STEP 1: EXPIRE OLD RECORDS
UPDATE dim_customers tgt
SET
    effective_end_date = CURRENT_TIMESTAMP(),
    is_current = FALSE
FROM customers_clean src
WHERE tgt.customer_id = src.customer_id
  AND tgt.is_current = TRUE
  AND (
        tgt.city <> src.city OR
        tgt.email <> src.email
      );

-- STEP 2: INSERT NEW RECORDS
INSERT INTO dim_customers (
    customer_id, first_name, email, city, created_at,
    effective_start_date, effective_end_date, is_current
)
SELECT
    src.customer_id, src.first_name, src.email, src.city, src.created_at,
    CURRENT_TIMESTAMP(), NULL, TRUE
FROM customers_clean src
LEFT JOIN dim_customers tgt
 ON src.customer_id = tgt.customer_id
 AND tgt.is_current = TRUE
WHERE tgt.customer_id IS NULL;

-- OTHER DIMENSIONS

CREATE OR REPLACE TABLE dim_restaurants AS
SELECT
    restaurant_id,
    restaurant_name,
    cuisine,
    city,
    rating
FROM restaurants_clean;

CREATE OR REPLACE TABLE dim_couriers AS
SELECT
    courier_id,
    courier_name,
    city
FROM couriers_clean;

CREATE OR REPLACE TABLE dim_date AS
SELECT DISTINCT
    DATE(order_datetime) AS order_date,
    YEAR(order_datetime) AS year,
    MONTH(order_datetime) AS month,
    DAY(order_datetime) AS day,
    DAYNAME(order_datetime) AS day_name
FROM orders_clean;

-- =====================================================
-- 5. FACT TABLE (FIXED AGGREGATION)
-- =====================================================

CREATE OR REPLACE TABLE fact_orders AS
SELECT
    o.order_id,
    o.customer_id,
    o.restaurant_id,
    d.courier_id,
    DATE(o.order_datetime) AS order_date,
    SUM(oi.quantity) AS total_quantity,
    SUM(oi.line_amount) AS total_amount,
    d.assign_time,
    d.drop_time,
    DATEDIFF('minute', d.assign_time, d.drop_time) AS delivery_minutes
FROM orders_clean o
JOIN order_items_clean oi ON o.order_id = oi.order_id
LEFT JOIN deliveries_clean d ON o.order_id = d.order_id
GROUP BY
    o.order_id,
    o.customer_id,
    o.restaurant_id,
    d.courier_id,
    order_date,
    d.assign_time,
    d.drop_time;

-- =====================================================
-- 6. DATA MASKING
-- =====================================================

CREATE OR REPLACE VIEW dim_customers_masked AS
SELECT
    customer_key,
    customer_id,
    first_name,
    CONCAT(LEFT(email,2),'****@',SPLIT_PART(email,'@',2)) AS email_masked,
    city,
    effective_start_date,
    effective_end_date,
    is_current
FROM dim_customers;

-- =====================================================
-- 7. AUDIT & ERROR LOGS
-- =====================================================

CREATE OR REPLACE TABLE etl_error_log (
    error_id INT AUTOINCREMENT,
    table_name VARCHAR,
    error_message VARCHAR,
    error_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);

CREATE OR REPLACE TABLE etl_audit_log (
    process_name VARCHAR,
    load_type VARCHAR,
    records_loaded INT,
    load_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);

-- INSERT AUDIT RECORD
INSERT INTO etl_audit_log (process_name, load_type, records_loaded)
SELECT 'customers_load', 'FULL', COUNT(*) FROM customers_clean;
