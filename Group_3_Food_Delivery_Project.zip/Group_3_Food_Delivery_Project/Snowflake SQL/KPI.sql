-- Food delivery KPI queries for AOV, delivery performance, revenue, and retention
-- Co-authored with CoCo
-- KPI 
USE DATABASE FOOD_DELIVERY_DB;
USE SCHEMA RAW;


--  1. Average Order Value (AOV)
-- AOV = Total Revenue / Total Number of Orders
SELECT 
    SUM(total_amount) AS total_revenue,
    COUNT(DISTINCT order_id) AS total_orders,
    ROUND(SUM(total_amount) / COUNT(DISTINCT order_id), 2) AS avg_order_value
FROM fact_orders;

-- 2. Delivery Fulfillment Time and On-Time Rate
-- a) Average Delivery Time
SELECT 
    ROUND(AVG(delivery_minutes),2) AS avg_delivery_time_minutes
FROM fact_orders
WHERE delivery_minutes IS NOT NULL;
-- b) On-Time Delivery Rate

SELECT
    ROUND(
        COUNT(CASE WHEN delivery_minutes <= 30 THEN 1 END) * 100.0 
        / COUNT(delivery_minutes)
    ,2) AS on_time_percentage
FROM fact_orders
WHERE delivery_minutes IS NOT NULL;

-- 3. Top Cuisines & Cities by Revenue
-- a) Top Cuisines by Revenue

SELECT 
    r.cuisine,
    SUM(f.total_amount) AS total_revenue
FROM fact_orders f
JOIN dim_restaurants r
    ON f.restaurant_id = r.restaurant_id
GROUP BY r.cuisine
ORDER BY total_revenue DESC
LIMIT 5;
describe table dim_restaurants;

-- b) Top Cities by Revenue

SELECT 
    r.city,
    SUM(f.total_amount) AS total_revenue
FROM fact_orders f
JOIN dim_restaurants r
    ON f.restaurant_id = r.restaurant_id
GROUP BY r.city
ORDER BY total_revenue DESC
LIMIT 5;

-- 4. Courier Performance

-- a) Average Delivery Time per Courier
SELECT 
    courier_id,
    ROUND(AVG(delivery_minutes),2) AS avg_delivery_time
FROM fact_orders
WHERE delivery_minutes IS NOT NULL
GROUP BY courier_id
ORDER BY avg_delivery_time;

--b) On-Time Rate per Courier
SELECT
    courier_id,
    COUNT(CASE WHEN delivery_minutes <= 30 THEN 1 END) * 100.0
    / COUNT(delivery_minutes) AS on_time_percentage
FROM fact_orders
WHERE delivery_minutes IS NOT NULL
GROUP BY courier_id
ORDER BY on_time_percentage DESC;

-- 5. Customer Retention Rate

-- Returning Customers %
SELECT 
    COUNT(DISTINCT CASE WHEN order_count > 1 THEN customer_id END) * 100.0
    / COUNT(DISTINCT customer_id) AS retention_rate
FROM (
    SELECT customer_id, COUNT(order_id) AS order_count
    FROM fact_orders
    GROUP BY customer_id
) t;

 

DESC TABLE dim_restaurants;


show tables;